const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./pdf-XWAOcuno.js","./capacitor-DmHSohtZ.js","./capacitor-CDunTGdz.css"])))=>i.map(i=>d[i]);
import{a as e,s as t}from"./capacitor-DmHSohtZ.js";var n=null;async function r(){return n||(n=(async()=>{let e=await t(()=>import(`./pdf-XWAOcuno.js`),__vite__mapDeps([0,1,2]),import.meta.url),n=await t(()=>import(`./pdf.worker.min-D5whv1nN.js`),[],import.meta.url);return e.GlobalWorkerOptions.workerSrc=n.default,e})(),n)}function i(e){let t=``,n=null;for(let r of e){let e=r.str??``,i=r.transform?.[5];if(n!==null&&i!==void 0&&Math.abs(i-n)>2.2)t.endsWith(`
`)||(t+=`
`);else if(t&&!t.endsWith(`
`)&&!t.endsWith(` `)&&e&&!e.startsWith(` `)){let n=t[t.length-1],r=e[0],i=e=>!!e&&/[\u3400-\u9fff]/.test(e);i(n)&&i(r)||(t+=` `)}t+=e,r.hasEOL&&!t.endsWith(`
`)&&(t+=`
`),i!==void 0&&(n=i)}return t}async function a(t){let n=await r(),a=new Uint8Array(t.slice(0)),o=await n.getDocument({data:a,useSystemFonts:!0,useWasm:!1,disableAutoFetch:!0,disableStream:!0,disableRange:!0,cMapUrl:`/pdfjs/cmaps/`,cMapPacked:!0,standardFontDataUrl:`/pdfjs/standard_fonts/`}).promise,s=[];for(let e=1;e<=o.numPages;e+=1){let t=i((await(await o.getPage(e)).getTextContent()).items);t.trim()&&s.push(t)}let c;try{let e=(await o.getMetadata()).info?.Title?.trim();e&&!/^untitled$/i.test(e)&&(c=e)}catch{}return{text:e(s.join(`

`)),pages:o.numPages,title:c}}export{a as pdfToText};