export const APP_NAME = "LinguaReader";
export const APP_VERSION = "1.5.73";
export const APP_VERSION_LABEL = `v${APP_VERSION}`;
export const APP_ID = "com.linguareader.app";
export const APP_VERSION_CODE = 10573;
