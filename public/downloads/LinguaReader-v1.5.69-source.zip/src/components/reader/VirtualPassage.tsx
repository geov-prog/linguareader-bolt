import { useLayoutEffect, useRef, useState } from "react";
import { HighlightedText } from "@/components/reader/FindBar";
import { cn } from "@/lib/utils";
import type { ReadingUnit } from "@/utils/sentences";

const WINDOW = 120;
const PAGE = 40;
const MAX_SPAN = 160;

function parkReadingLine(root: HTMLElement, el: HTMLElement, force: boolean) {
  const box = root.getBoundingClientRect();
  const row = el.getBoundingClientRect();
  const topGap = 12;
  const bottomGap = 36;
  if (!force && row.top >= box.top + topGap && row.bottom <= box.bottom - bottomGap) return false;
  const park = Math.max(16, Math.min(72, box.height * 0.08));
  root.scrollTop = Math.max(0, root.scrollTop + (row.top - box.top) - park);
  return true;
}

export function VirtualPassage({
  units,
  activeIndex,
  findQuery,
  activeStart,
  followPlayback = false,
  revealNonce = 0,
  onJump,
  onUserScroll,
}: {
  units: ReadingUnit[];
  activeIndex: number;
  fontSize: number;
  findQuery: string;
  activeStart: number | null;
  followPlayback?: boolean;
  revealNonce?: number;
  onJump: (index: number) => void;
  onUserScroll?: () => void;
}) {
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const followRef = useRef(followPlayback);
  followRef.current = followPlayback;
  const prependLock = useRef(false);
  const ignoreUser = useRef(false);
  const anchorRef = useRef<{ index: number; top: number } | null>(null);
  const seenReveal = useRef(revealNonce);
  const n = units.length;
  const [range, setRange] = useState(() => {
    const start = Math.max(0, activeIndex - 24);
    return { start, end: Math.min(n, start + WINDOW) };
  });

  const slice = units.slice(range.start, range.end);

  useLayoutEffect(() => {
    const jump = revealNonce !== seenReveal.current;
    if (!followPlayback && !jump) return;
    if (!jump && activeIndex >= range.start + 8 && activeIndex < range.end - 8) return;
    const start = Math.max(0, Math.min(activeIndex - 24, Math.max(0, n - WINDOW)));
    const end = Math.min(n, start + WINDOW);
    if (start === range.start && end === range.end) return;
    setRange({ start, end });
  }, [activeIndex, n, range.start, range.end, revealNonce, followPlayback]);

  useLayoutEffect(() => {
    const root = scrollerRef.current;
    const anchor = anchorRef.current;
    if (root && anchor) {
      const pinned = root.querySelector(`[data-sent="${anchor.index}"]`);
      if (pinned instanceof HTMLElement) {
        root.scrollTop += pinned.getBoundingClientRect().top - anchor.top;
      }
      anchorRef.current = null;
      prependLock.current = false;
    }

    const jump = revealNonce !== seenReveal.current;

    if (!followPlayback && !jump) return;
    if (!root) return;
    const el = root.querySelector(`[data-sent="${activeIndex}"]`);
    if (!(el instanceof HTMLElement)) return;
    if (jump) seenReveal.current = revealNonce;
    const moved = parkReadingLine(root, el, jump);
    if (!moved) return;
    ignoreUser.current = true;
    window.setTimeout(() => {
      ignoreUser.current = false;
    }, 80);
  }, [activeIndex, range.start, range.end, revealNonce, followPlayback]);

  const shiftEarlier = () => {
    const root = scrollerRef.current;
    if (!root || range.start <= 0 || prependLock.current) return;
    prependLock.current = true;
    const boxTop = root.getBoundingClientRect().top;
    let anchorIndex = range.start;
    let anchorTop = boxTop;
    for (let i = range.start; i < range.end; i += 1) {
      const el = root.querySelector(`[data-sent="${i}"]`);
      if (!(el instanceof HTMLElement)) continue;
      const top = el.getBoundingClientRect().top;
      if (top >= boxTop - 4) {
        anchorIndex = i;
        anchorTop = top;
        break;
      }
    }
    anchorRef.current = { index: anchorIndex, top: anchorTop };
    const nextStart = Math.max(0, range.start - PAGE);
    const nextEnd = range.end - range.start > MAX_SPAN ? Math.min(n, range.end - PAGE) : range.end;
    setRange({ start: nextStart, end: nextEnd });
  };

  const shiftLater = () => {
    if (range.end >= n) return;
    const nextEnd = Math.min(n, range.end + PAGE);
    const nextStart = nextEnd - range.start > MAX_SPAN ? nextEnd - MAX_SPAN : range.start;
    setRange({ start: nextStart, end: nextEnd });
  };

  const noteUserScroll = () => {
    if (ignoreUser.current) return;
    followRef.current = false;
    onUserScroll?.();
  };

  const onScroll = () => {
    const root = scrollerRef.current;
    if (!root) return;
    if (!ignoreUser.current && followRef.current) {
      const activeEl = root.querySelector(`[data-sent="${activeIndex}"]`);
      if (activeEl) {
        const box = root.getBoundingClientRect();
        const r = activeEl.getBoundingClientRect();
        if (r.bottom < box.top + 8 || r.top > box.bottom - 8) noteUserScroll();
      }
    }
    if (root.scrollTop < 48 && range.start > 0) shiftEarlier();
    if (root.scrollHeight - root.scrollTop - root.clientHeight < 72 && range.end < n) shiftLater();
  };

  if (!n) return null;

  return (
    <div
      ref={scrollerRef}
      data-reader-scroll="book"
      onScroll={onScroll}
      onWheel={noteUserScroll}
      onTouchStart={noteUserScroll}
      onTouchMove={noteUserScroll}
      className="h-full min-h-[12rem] overflow-y-auto overscroll-y-none pr-1"
      style={{
        WebkitOverflowScrolling: "touch",
        touchAction: "pan-y",
        overflowAnchor: "none",
      }}
    >
      {range.start > 0 ? (
        <button
          type="button"
          className="mb-3 w-full rounded-lg bg-paper-sunken py-2 font-sans text-xs text-ink"
          onClick={() => {
            followRef.current = false;
            onUserScroll?.();
            shiftEarlier();
          }}
        >
          Earlier in the book · {range.start.toLocaleString()} before
        </button>
      ) : null}
      {slice.map((unit, offset) => {
        const index = range.start + offset;
        const active = index === activeIndex;
        const matchStart = active && activeStart != null ? activeStart : null;
        return (
          <div key={index} data-sent={index} style={{ overflowAnchor: "none" }}>
            {unit.para && offset > 0 ? <div className="h-[0.95em]" /> : null}
            <div
              role="button"
              tabIndex={-1}
              onClick={() => onJump(index)}
              className={cn(
                "w-full min-w-0 cursor-pointer overflow-x-clip break-all rounded-sm px-0.5 py-0.5 text-left transition-[background-color,box-shadow,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
                active
                  ? "bg-mark text-ink shadow-[inset_3px_0_0_0_var(--color-pine)]"
                  : "hover:bg-paper-sunken/80",
              )}
            >
              <HighlightedText text={unit.text} query={findQuery} activeStart={matchStart} />
            </div>
          </div>
        );
      })}
      {range.end < n ? (
        <button
          type="button"
          className="mt-3 mb-6 w-full rounded-lg bg-paper-sunken py-2 font-sans text-xs text-ink"
          onClick={() => {
            followRef.current = false;
            onUserScroll?.();
            shiftLater();
          }}
        >
          Later in the book · {(n - range.end).toLocaleString()} after
        </button>
      ) : (
        <div className="h-8" />
      )}
    </div>
  );
}
