import { splitSentences } from "@/utils/sentences";

export interface ChapterMark {
  title: string;
  charOffset: number;
  sentenceIndex: number;
}

const CN = "0-9０-９一二三四五六七八九十百千万零〇两";

function isChapterLine(line: string): boolean {
  const text = line.trim();
  if (!text || text.length > 80) return false;
  if (new RegExp(`^第\\s*[${CN}]+\\s*[章节回卷部集]`).test(text)) return true;
  if (/^(chapter|ch\.?)\s+\d+/i.test(text)) return true;
  if (/^\d{1,5}$/.test(text)) return true;
  return false;
}

export function scanChapters(rawText: string, sentences?: string[]): ChapterMark[] {
  const text = rawText.replace(/\r\n/g, "\n");
  const units = sentences ?? splitSentences(text);
  const found: { title: string; charOffset: number }[] = [];
  let offset = 0;
  for (const line of text.split("\n")) {
    if (isChapterLine(line)) {
      found.push({ title: line.trim().slice(0, 72), charOffset: offset });
    }
    offset += line.length + 1;
  }
  return found.map((chapter) => ({
    ...chapter,
    sentenceIndex: sentenceIndexFor(units, chapter.title),
  }));
}

function sentenceIndexFor(sentences: string[], title: string): number {
  const key = title.replace(/\s+/g, "").slice(0, 18);
  if (!key) return 0;
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i]!.replace(/\s+/g, "");
    if (sentence.includes(key) || key.startsWith(sentence.slice(0, Math.min(8, sentence.length)))) return i;
  }
  return 0;
}
