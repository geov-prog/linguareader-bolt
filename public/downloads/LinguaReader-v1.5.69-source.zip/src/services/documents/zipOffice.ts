import { cleanExtractedText, stripXmlTags } from "@/services/documents/clean";
import { htmlToText, xmlToText } from "@/services/documents/html";
import { pdfToText } from "@/services/documents/pdf";
import { TextNormalizationService } from "@/utils/textNormalization";

type JSZip = import("jszip");
type ZipObject = import("jszip").JSZipObject;

function normalizeZipPath(name: string): string {
  return name.replace(/\\/g, "/").replace(/^\.\//, "").replace(/^\/+/, "");
}

function decodeHref(value: string): string {
  const trimmed = value.trim();
  try {
    return decodeURIComponent(trimmed);
  } catch {
    return trimmed.replace(/%20/g, " ");
  }
}

function pathKey(name: string): string {
  return normalizeZipPath(decodeHref(name)).toLowerCase();
}

async function loadZip(buffer: ArrayBuffer): Promise<JSZip> {
  const JSZipMod = (await import("jszip")).default;
  const sliced = sliceToZip(buffer);
  try {
    return await JSZipMod.loadAsync(sliced);
  } catch {
    if (sliced !== buffer) return JSZipMod.loadAsync(buffer);
    throw new Error("That file looks damaged or is not a real Word/EPUB document.");
  }
}

function sliceToZip(buffer: ArrayBuffer): ArrayBuffer {
  const bytes = new Uint8Array(buffer);
  const limit = Math.min(bytes.length - 4, 2048);
  for (let i = 0; i <= limit; i += 1) {
    if (bytes[i] === 0x50 && bytes[i + 1] === 0x4b && (bytes[i + 2] === 0x03 || bytes[i + 2] === 0x05 || bytes[i + 2] === 0x07)) {
      return i === 0 ? buffer : buffer.slice(i);
    }
  }
  return buffer;
}

function fileNames(zip: JSZip): string[] {
  return Object.keys(zip.files).filter((name) => !zip.files[name]?.dir);
}

function findZipEntry(zip: JSZip, name: string): ZipObject | null {
  const wanted = [
    name,
    decodeHref(name),
    normalizeZipPath(name),
    normalizeZipPath(decodeHref(name)),
  ];
  for (const candidate of wanted) {
    const hit = zip.file(candidate);
    if (hit && !hit.dir) return hit;
  }
  const key = pathKey(name);
  const match = fileNames(zip).find((entry) => pathKey(entry) === key);
  return match ? zip.files[match] ?? null : null;
}

async function readDecoded(zip: JSZip, name: string): Promise<string | null> {
  const file = findZipEntry(zip, name);
  if (!file) return null;
  const buffer = await file.async("arraybuffer");
  return TextNormalizationService.decode(buffer).text;
}

async function readBuffer(zip: JSZip, name: string): Promise<ArrayBuffer | null> {
  const file = findZipEntry(zip, name);
  if (!file) return null;
  return file.async("arraybuffer");
}

function sortNumeric(a: string, b: string): number {
  const na = Number.parseInt(a.match(/(\d+)/)?.[1] ?? "0", 10);
  const nb = Number.parseInt(b.match(/(\d+)/)?.[1] ?? "0", 10);
  if (na !== nb) return na - nb;
  return a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" });
}

function looksLikeEpub(names: string[], mime: string): boolean {
  if (mime.toLowerCase().includes("epub")) return true;
  return names.some((n) => {
    const key = pathKey(n);
    return key === "meta-inf/container.xml" || key.endsWith(".opf");
  });
}

export async function zipContainerToText(
  buffer: ArrayBuffer,
): Promise<{ text: string; formatLabel: string; encoding: string; title?: string }> {
  const zip = await loadZip(buffer);
  const names = fileNames(zip);

  if (names.some((n) => pathKey(n) === "word/document.xml" || pathKey(n).startsWith("word/"))) {
    const word = await docxToText(buffer, zip);
    if (!word.text) {
      throw new Error("That Word file has no readable text. Try exporting it as .docx or PDF.");
    }
    return { ...word, formatLabel: "Word", encoding: "docx" };
  }
  if (names.some((n) => pathKey(n).startsWith("xl/"))) {
    return { text: await spreadsheetToText(buffer), formatLabel: "Excel", encoding: "xlsx" };
  }
  if (names.some((n) => pathKey(n).startsWith("ppt/"))) {
    return { text: await pptxToText(zip, names), formatLabel: "PowerPoint", encoding: "pptx" };
  }

  const mime = ((await readDecoded(zip, "mimetype")) ?? "").trim();
  if (names.some((n) => pathKey(n) === "content.xml") || mime.includes("opendocument")) {
    if (mime.includes("spreadsheet") || names.some((n) => pathKey(n).includes("xl/"))) {
      return { text: await odfToText(zip), formatLabel: "OpenDocument spreadsheet", encoding: "ods" };
    }
    if (mime.includes("presentation")) {
      return { text: await odfToText(zip), formatLabel: "OpenDocument slides", encoding: "odp" };
    }
    return { text: await odfToText(zip), formatLabel: "OpenDocument text", encoding: "odt" };
  }

  if (looksLikeEpub(names, mime)) {
    if (names.some((n) => pathKey(n) === "meta-inf/encryption.xml")) {
      throw new Error("This EPUB is locked (DRM). Export a copy without protection, or paste the text.");
    }
    const epub = await epubToText(zip);
    if (!epub.text) {
      throw new Error("That EPUB has no readable chapters. Try another export, or a PDF/Word copy.");
    }
    return { ...epub, formatLabel: "EPUB", encoding: "epub" };
  }

  const previewName =
    names.find((n) => /quicklook\/preview\.pdf$/i.test(n)) ?? names.find((n) => /preview\.pdf$/i.test(n));
  if (previewName || names.some((n) => n.endsWith(".iwa"))) {
    if (previewName) {
      const preview = await readBuffer(zip, previewName);
      if (preview) {
        const pdf = await pdfToText(preview);
        if (pdf.text) return { text: pdf.text, formatLabel: "Pages", encoding: "pages", title: pdf.title };
      }
    }
    throw new Error("That Pages file has no readable preview. Export it as PDF or Word and drop it again.");
  }

  const textFiles = names.filter((n) => /\.(txt|md|html?|xhtml|xml|csv|rtf|json)$/i.test(n));
  if (textFiles.length) {
    const parts: string[] = [];
    for (const name of textFiles.sort(sortNumeric)) {
      const raw = await readDecoded(zip, name);
      if (!raw) continue;
      const body = /\.x?html?/i.test(name) ? htmlToText(raw) : cleanExtractedText(raw);
      if (body) parts.push(textFiles.length > 1 ? `${name}\n${body}` : body);
    }
    const text = cleanExtractedText(parts.join("\n\n"));
    if (text) return { text, formatLabel: "Archive", encoding: "zip" };
  }

  throw new Error("That archive is not a readable document. Try Word, PDF, EPUB, or a text file.");
}

function mammothApi(mod: Record<string, unknown>): { extractRawText?: (opts: { arrayBuffer: ArrayBuffer }) => Promise<{ value?: string }> } {
  const nested = mod.default as Record<string, unknown> | undefined;
  if (typeof mod.extractRawText === "function") return mod as never;
  if (nested && typeof nested.extractRawText === "function") return nested as never;
  return {};
}

async function docxToText(buffer: ArrayBuffer, zip: JSZip): Promise<{ text: string; title?: string }> {
  try {
    const mammothMod = (await import("mammoth")) as Record<string, unknown>;
    const mammoth = mammothApi(mammothMod);
    if (mammoth.extractRawText) {
      const result = await mammoth.extractRawText({ arrayBuffer: buffer });
      const text = cleanExtractedText(result.value ?? "");
      if (text) return { text };
    }
  } catch {
    // fall through to XML
  }
  const xml =
    (await readDecoded(zip, "word/document.xml")) ?? (await readDecoded(zip, "word/document2.xml"));
  if (!xml) throw new Error("That Word file is missing its document part.");
  const extras: string[] = [];
  for (const name of fileNames(zip)) {
    if (/word\/(header|footer|footnotes|endnotes|comments)[^/]*\.xml$/i.test(normalizeZipPath(name))) {
      const raw = await readDecoded(zip, name);
      if (raw) extras.push(stripXmlTags(raw));
    }
  }
  return { text: cleanExtractedText([stripXmlTags(xml), ...extras].join("\n\n")) };
}

async function spreadsheetToText(buffer: ArrayBuffer): Promise<string> {
  const XLSX = await import("xlsx");
  const workbook = XLSX.read(new Uint8Array(buffer), { type: "array" });
  const parts: string[] = [];
  for (const name of workbook.SheetNames) {
    const sheet = workbook.Sheets[name];
    if (!sheet) continue;
    const csv = XLSX.utils.sheet_to_csv(sheet, { blankrows: false });
    if (csv.trim()) parts.push(workbook.SheetNames.length > 1 ? `${name}\n${csv}` : csv);
  }
  return cleanExtractedText(parts.join("\n\n"));
}

async function pptxToText(zip: JSZip, names: string[]): Promise<string> {
  const slides = names.filter((n) => /ppt\/slides\/slide\d+\.xml$/i.test(n)).sort(sortNumeric);
  const notes = names.filter((n) => /ppt\/notesSlides\/notesSlide\d+\.xml$/i.test(n)).sort(sortNumeric);
  const parts: string[] = [];
  for (let i = 0; i < slides.length; i += 1) {
    const xml = await readDecoded(zip, slides[i]!);
    const body = xml ? xmlToText(xml) : "";
    const noteXml = notes[i] ? await readDecoded(zip, notes[i]!) : null;
    const note = noteXml ? xmlToText(noteXml) : "";
    const chunk = [body, note].filter(Boolean).join("\n");
    if (chunk) parts.push(chunk);
  }
  return cleanExtractedText(parts.join("\n\n"));
}

async function odfToText(zip: JSZip): Promise<string> {
  const xml = (await readDecoded(zip, "content.xml")) ?? "";
  return cleanExtractedText(stripXmlTags(xml));
}

function attr(tag: string, name: string): string | undefined {
  return tag.match(new RegExp(`\\b${name}\\s*=\\s*["']([^"']+)["']`, "i"))?.[1];
}

async function htmlFilesToText(zip: JSZip, names: string[]): Promise<string> {
  const files = names
    .filter((n) => /\.(x?html?)$/i.test(n))
    .filter((n) => !/meta-inf\//i.test(n))
    .sort(sortNumeric);
  const preferred = files.filter((n) => !/(nav|toc|ncx|cover|title.?page)/i.test(n));
  const ordered = preferred.length ? preferred : files;
  const parts: string[] = [];
  for (const name of ordered) {
    const raw = await readDecoded(zip, name);
    if (!raw) continue;
    const body = htmlToText(raw);
    if (body) parts.push(body);
  }
  return cleanExtractedText(parts.join("\n\n"));
}

async function epubToText(zip: JSZip): Promise<{ text: string; title?: string }> {
  const names = fileNames(zip);
  const container = await readDecoded(zip, "META-INF/container.xml");
  const rootHref =
    container?.match(/full-path\s*=\s*["']([^"']+)["']/i)?.[1] ??
    names.find((n) => pathKey(n).endsWith(".opf"));
  if (!rootHref) {
    return { text: await htmlFilesToText(zip, names) };
  }
  const opf = await readDecoded(zip, rootHref);
  if (!opf) {
    return { text: await htmlFilesToText(zip, names) };
  }
  const base = normalizeZipPath(rootHref).replace(/[^/]+$/, "");
  const title = xmlToText(opf.match(/<dc:title\b[^>]*>([\s\S]*?)<\/dc:title>/i)?.[1] ?? "");
  const manifest = new Map<string, string>();
  const itemRe = /<item\b[^>]*>/gi;
  let match: RegExpExecArray | null;
  while ((match = itemRe.exec(opf))) {
    const tag = match[0];
    const id = attr(tag, "id");
    const href = attr(tag, "href");
    if (id && href) manifest.set(id, href);
  }
  const spineIds = [...opf.matchAll(/<itemref\b[^>]*\bidref\s*=\s*["']([^"']+)["']/gi)].map((m) => m[1]!);
  const hrefs = (
    spineIds.length ? spineIds.map((id) => manifest.get(id)).filter(Boolean) : [...manifest.values()]
  ) as string[];
  const parts: string[] = [];
  const seen = new Set<string>();
  for (const href of hrefs) {
    const path = resolveZipPath(base, decodeHref(href));
    const key = pathKey(path);
    if (seen.has(key)) continue;
    seen.add(key);
    const raw = await readDecoded(zip, path);
    if (!raw) continue;
    if (!/\.(x?html?|xml|htm)$/i.test(path) && !/<html\b/i.test(raw.slice(0, 800))) continue;
    const body = htmlToText(raw);
    if (body) parts.push(body);
  }
  let text = cleanExtractedText(parts.join("\n\n"));
  if (!text) text = await htmlFilesToText(zip, names);
  return { text, title: title || undefined };
}

function resolveZipPath(base: string, href: string): string {
  const cleaned = decodeHref(href.split("?")[0]?.split("#")[0] ?? href);
  if (/^https?:/i.test(cleaned)) return cleaned;
  const prefix = normalizeZipPath(base);
  const joined = cleaned.startsWith("/") ? cleaned : `${prefix}${cleaned}`;
  const stack = joined.split("/");
  const out: string[] = [];
  for (const part of stack) {
    if (!part || part === ".") continue;
    if (part === "..") out.pop();
    else out.push(part);
  }
  return out.join("/");
}
