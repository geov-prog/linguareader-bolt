import { speakStoryChunk } from "@/lib/story-tts";
import { speakEdgeMp3 } from "@/services/media/edgeSpeak";
import { getTtsClip, putTtsClip } from "@/services/StorageService";
import { fetchAndroidStory } from "@/services/media/AndroidVoices";
import { isInstalledAndroidApp, isIOS } from "@/utils/platform";

export const STORY_PREFIX = "story:";
export const STORY_AUTO = "story:auto";

export type StoryGender = "female" | "male";
export type StoryLang = "zh" | "en";

export interface StoryVoice {
  id: string;
  uri: string;
  name: string;
  hint: string;
  lang: StoryLang;
  gender: StoryGender;
  neural: string;
}

export const STORY_VOICES: StoryVoice[] = [
  {
    id: "lin-hua",
    uri: `${STORY_PREFIX}lin-hua`,
    name: "林华",
    hint: "女声 · 中文小说",
    lang: "zh",
    gender: "female",
    neural: "zh-CN-XiaoyiNeural",
  },
  {
    id: "shen-yan",
    uri: `${STORY_PREFIX}shen-yan`,
    name: "沈言",
    hint: "男声 · 中文小说",
    lang: "zh",
    gender: "male",
    neural: "zh-CN-YunxiNeural",
  },
  {
    id: "clara",
    uri: `${STORY_PREFIX}clara`,
    name: "Clara",
    hint: "Female · English novels",
    lang: "en",
    gender: "female",
    neural: "en-US-JennyNeural",
  },
  {
    id: "rowan",
    uri: `${STORY_PREFIX}rowan`,
    name: "Rowan",
    hint: "Male · English novels",
    lang: "en",
    gender: "male",
    neural: "en-US-GuyNeural",
  },
];

export function isStoryVoiceURI(uri: string | null | undefined): boolean {
  return !!uri?.startsWith(STORY_PREFIX);
}

export function getStoryVoice(uri: string | null | undefined): StoryVoice | null {
  if (!uri?.startsWith(STORY_PREFIX) || uri === STORY_AUTO) return null;
  const id = uri.slice(STORY_PREFIX.length);
  return STORY_VOICES.find((v) => v.id === id) ?? null;
}

export function pickStoryVoice(uri: string | null | undefined, lang: StoryLang): StoryVoice {
  const explicit = getStoryVoice(uri);
  if (explicit) return explicit;
  if (lang === "en") return STORY_VOICES.find((v) => v.id === "clara") ?? STORY_VOICES[0]!;
  return STORY_VOICES.find((v) => v.id === "lin-hua") ?? STORY_VOICES[0]!;
}

export async function loadStoryteller(): Promise<boolean> {
  return true;
}

export function storytellerReady(): boolean {
  return true;
}

function b64ToBlob(b64: string, mime: string): Blob {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime || "audio/mpeg" });
}

export function sanitizeNeural(
  neural: string | undefined,
  lang: StoryLang,
  gender: "female" | "male" | "unknown" = "female",
): string {
  const n = neural || "";
  const male = gender === "male";
  if (lang === "zh") {
    if (/^zh-CN-(Xiaoyi|Xiaoxiao|Yunxi|Yunyang|Yunjian)Neural$/.test(n)) return n;
    return male ? "zh-CN-YunxiNeural" : "zh-CN-XiaoyiNeural";
  }
  if (/^en-US-(Jenny|Aria|Guy|Andrew)Neural$/.test(n)) return n;
  return male ? "en-US-GuyNeural" : "en-US-JennyNeural";
}

function isProbablyMp3(blob: Blob): boolean {
  return blob.size > 1200 && /mpeg|mp3|audio/i.test(blob.type || "audio/mpeg");
}

async function clipId(neural: string, pitch: string, rate: number, text: string): Promise<string> {
  const raw = `v3|${neural}|${pitch}|${rate.toFixed(2)}|${text}`;
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  let h = 2166136261;
  for (let i = 0; i < raw.length; i++) h = Math.imul(h ^ raw.charCodeAt(i), 16777619);
  return `h${(h >>> 0).toString(16)}-${raw.length}`;
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Storyteller timed out")), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      },
    );
  });
}

function rateToEdge(rate: number): string {
  const pct = Math.round((Math.max(0.6, Math.min(1.8, rate || 1)) - 1) * 100);
  return `${pct >= 0 ? "+" : ""}${pct}%`;
}

async function synthesizeInBrowser(text: string, neural: string, rate: number, pitch: string): Promise<Blob> {
  const bytes = await withTimeout(
    speakEdgeMp3(text, neural, rateToEdge(rate), pitch),
    isNativeApp() ? 8000 : 14000,
  );
  const copy = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(copy).set(bytes);
  return new Blob([copy], { type: "audio/mpeg" });
}

function desktopSpeak(): LinguaDesktopApi["speak"] | null {
  if (typeof window === "undefined") return null;
  const speak = window.linguaDesktop?.speak;
  return typeof speak === "function" ? speak : null;
}

async function synthesizeOnDesktop(text: string, neural: string, rate: number, pitch: string): Promise<Blob> {
  const speak = desktopSpeak();
  if (!speak) throw new Error("no desktop voice");
  const result = await withTimeout(speak({ text, voice: neural, rate, pitch }), 18000);
  if (!result?.b64) throw new Error("empty desktop voice");
  return b64ToBlob(result.b64, result.mime || "audio/mpeg");
}

function isNativeApp(): boolean {
  if (typeof window === "undefined") return false;
  const cap = (window as Window & { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  if (cap?.isNativePlatform?.()) return true;
  const href = window.location?.href || "";
  if (href.startsWith("capacitor:") || href.startsWith("file:")) return true;
  const host = window.location?.hostname || "";
  return host === "localhost" && /; wv\)/i.test(navigator.userAgent);
}

async function audioBytes(audio: Blob | ArrayBuffer | Uint8Array): Promise<Uint8Array> {
  if (audio instanceof ArrayBuffer) return new Uint8Array(audio.slice(0));
  if (ArrayBuffer.isView(audio)) {
    const view = new Uint8Array(audio.buffer, audio.byteOffset, audio.byteLength);
    const copy = new Uint8Array(view.byteLength);
    copy.set(view);
    return copy;
  }
  return new Uint8Array(await audio.arrayBuffer());
}

function isSpokenMp3(bytes: Uint8Array): boolean {
  if (bytes.byteLength < 1200) return false;
  const marker = String.fromCharCode(bytes[0] ?? 0, bytes[1] ?? 0, bytes[2] ?? 0, bytes[3] ?? 0);
  if (marker.startsWith("<") || marker.startsWith("{") || marker === "RIFF" || marker === "OggS") return false;
  let start = 0;
  if (bytes[0] === 0x49 && bytes[1] === 0x44 && bytes[2] === 0x33 && bytes.byteLength > 10) {
    const size = ((bytes[6]! & 0x7f) << 21) | ((bytes[7]! & 0x7f) << 14) | ((bytes[8]! & 0x7f) << 7) | (bytes[9]! & 0x7f);
    start = Math.min(bytes.byteLength - 2, 10 + size);
  }
  const end = Math.min(bytes.byteLength - 1, start + 8192);
  for (let i = start; i < end; i++) {
    if (bytes[i] === 0xff && ((bytes[i + 1] ?? 0) & 0xe0) === 0xe0) return true;
  }
  return false;
}

async function synthesizeOnAndroid(text: string, neural: string, rate: number, pitch: string): Promise<Blob> {
  const blob = await fetchAndroidStory(text, neural, rateToEdge(rate), pitch);
  const bytes = await audioBytes(blob);
  if (!isSpokenMp3(bytes)) throw new Error("android-voice-unusable");
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return new Blob([copy], { type: "audio/mpeg" });
}

function canUseBrowserEdge(): boolean {
  return typeof navigator !== "undefined";
}

function voiceForPage(uri: string | null | undefined, lang: StoryLang): StoryVoice {
  const picked = pickStoryVoice(uri, lang);
  if (picked.lang === lang) return picked;
  if (lang === "zh") {
    return pickStoryVoice(picked.gender === "male" ? `${STORY_PREFIX}shen-yan` : `${STORY_PREFIX}lin-hua`, "zh");
  }
  return pickStoryVoice(picked.gender === "male" ? `${STORY_PREFIX}rowan` : `${STORY_PREFIX}clara`, "en");
}

function fallbackNeurals(voice: StoryVoice, lang: StoryLang): string[] {
  if (lang === "zh") {
    if (voice.gender === "male") {
      return ["zh-CN-YunxiNeural", "zh-CN-YunyangNeural", "zh-CN-XiaoyiNeural", "zh-CN-XiaoxiaoNeural"];
    }
    return ["zh-CN-XiaoyiNeural", "zh-CN-XiaoxiaoNeural", "zh-CN-YunxiNeural"];
  }
  if (voice.gender === "male") return ["en-US-GuyNeural", "en-US-AndrewNeural", "en-US-JennyNeural"];
  return ["en-US-JennyNeural", "en-US-AriaNeural", "en-US-GuyNeural"];
}

async function fetchFastestOnIphone(text: string, neural: string, rate: number, pitch: string): Promise<Blob> {
  const server = withTimeout(
    speakStoryChunk({ data: { text, voice: neural, rate, pitch } }),
    7000,
  ).then((result) => b64ToBlob(result.b64, result.mime));
  const local = synthesizeInBrowser(text, neural, rate, pitch);
  try {
    return await Promise.any([server, local]);
  } catch {
    return server;
  }
}

async function fetchClip(text: string, neural: string, rate: number, pitch: string): Promise<Blob> {
  const id = await clipId(neural, pitch, rate, text);
  const cached = await getTtsClip(id);
  if (cached && isProbablyMp3(cached)) return cached;
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    throw new Error("offline");
  }
  let blob: Blob | null = null;
  const desktop = desktopSpeak();
  if (desktop) {
    blob = await synthesizeOnDesktop(text, neural, rate, pitch);
  } else if (isNativeApp()) {
    blob = await synthesizeInBrowser(text, neural, rate, pitch);
  } else if (isIOS()) {
    blob = await fetchFastestOnIphone(text, neural, rate, pitch);
  } else {
    try {
      const result = await withTimeout(
        speakStoryChunk({
          data: { text, voice: neural, rate, pitch },
        }),
        8000,
      );
      blob = b64ToBlob(result.b64, result.mime);
    } catch {
      if (!canUseBrowserEdge()) throw new Error("Could not fetch that voice");
      blob = await synthesizeInBrowser(text, neural, rate, pitch);
    }
  }
  if (blob.size > 1200) void putTtsClip(id, blob);
  return blob;
}

export async function speakWithStoryteller(
  text: string,
  lang: StoryLang,
  uri: string | null | undefined,
  rate: number,
  extras?: { neural?: string; pitch?: string },
): Promise<Blob> {
  const voice = voiceForPage(uri, lang);
  if (isInstalledAndroidApp()) {
    const neural = sanitizeNeural(extras?.neural || voice.neural, lang, voice.gender);
    const pitch = extras?.pitch && extras.pitch !== "+0Hz" ? extras.pitch : "+0Hz";
    const id = await clipId(neural, pitch, rate, text);
    const saved = await getTtsClip(id);
    if (saved) {
      const cachedBytes = await audioBytes(saved);
      if (isSpokenMp3(cachedBytes)) {
        const copy = new Uint8Array(cachedBytes.byteLength);
        copy.set(cachedBytes);
        return new Blob([copy], { type: "audio/mpeg" });
      }
    }
    const blob = await synthesizeOnAndroid(text, neural, rate, pitch);
    void putTtsClip(id, blob);
    return blob;
  }
  const extrasNeural = extras?.neural ? sanitizeNeural(extras.neural, lang, voice.gender) : undefined;
  const chain = isNativeApp()
    ? [extrasNeural || voice.neural]
    : [extrasNeural, ...fallbackNeurals(voice, lang)].filter((name): name is string => !!name);
  const pitches = extras?.pitch && extras.pitch !== "+0Hz" ? [extras.pitch, "+0Hz"] : ["+0Hz"];
  const seen = new Set<string>();
  let lastError: unknown;
  for (const neural of chain) {
    for (const pitch of pitches) {
      const key = `${neural}|${pitch}`;
      if (seen.has(key)) continue;
      seen.add(key);
      try {
        const blob = await fetchClip(text, neural, rate, pitch);
        if (blob.size > 800) return blob;
      } catch (err) {
        lastError = err;
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Could not mix that voice");
}
