package com.linguareader.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.content.ContextCompat;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "ReadingKeepAlive")
public class ReadingKeepAlivePlugin extends Plugin {
  @PluginMethod
  public void start(PluginCall call) {
    try {
      if (Build.VERSION.SDK_INT >= 33
          && getActivity() != null
          && ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS)
              != PackageManager.PERMISSION_GRANTED) {
        getActivity().requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 74);
      }
      Intent intent = new Intent(getContext(), ReadingService.class);
      ContextCompat.startForegroundService(getContext(), intent);
      call.resolve();
    } catch (Exception err) {
      call.reject(err.getMessage());
    }
  }

  @PluginMethod
  public void stop(PluginCall call) {
    try {
      getContext().stopService(new Intent(getContext(), ReadingService.class));
      call.resolve();
    } catch (Exception err) {
      call.reject(err.getMessage());
    }
  }
}
