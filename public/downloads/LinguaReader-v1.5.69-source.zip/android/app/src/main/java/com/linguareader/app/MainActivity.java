package com.linguareader.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(ReadingKeepAlivePlugin.class);
    registerPlugin(PhoneVoicePlugin.class);
    super.onCreate(savedInstanceState);
  }
}
