package com.linguareader.app;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

@CapacitorPlugin(name = "PhoneVoice")
public class PhoneVoicePlugin extends Plugin {
  private static final String TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";
  private TextToSpeech tts;
  private boolean ready = false;
  private final List<Runnable> waiting = new ArrayList<>();
  private PluginCall speaking;
  private final OkHttpClient http =
      new OkHttpClient.Builder()
          .connectTimeout(15, TimeUnit.SECONDS)
          .readTimeout(25, TimeUnit.SECONDS)
          .build();

  @PluginMethod
  public void list(PluginCall call) {
    withEngine(
        () -> {
          JSArray voices = new JSArray();
          Set<Voice> found = tts.getVoices();
          if (found != null) {
            for (Voice voice : found) {
              Set<String> features = voice.getFeatures();
              if (features != null && features.contains("notInstalled")) continue;
              JSObject item = new JSObject();
              item.put("id", voice.getName());
              item.put("name", voice.getName());
              item.put("lang", voice.getLocale() == null ? "" : voice.getLocale().toLanguageTag());
              item.put("features", features == null ? "" : joinFeatures(features));
              voices.put(item);
            }
          }
          JSObject result = new JSObject();
          result.put("voices", voices);
          call.resolve(result);
        },
        call);
  }

  @PluginMethod
  public void speak(PluginCall call) {
    String text = call.getString("text", "");
    String id = call.getString("id", "");
    double rate = call.getDouble("rate", 1.0);
    if (text == null || text.trim().isEmpty()) {
      call.reject("empty");
      return;
    }
    withEngine(
        () -> {
          if (speaking != null) {
            speaking.reject("replaced");
            speaking = null;
            tts.stop();
          }
          Voice match = null;
          Set<Voice> found = tts.getVoices();
          if (found != null) {
            for (Voice voice : found) {
              if (voice.getName().equals(id)) {
                match = voice;
                break;
              }
            }
          }
          if (match != null) tts.setVoice(match);
          tts.setSpeechRate((float) Math.max(0.5, Math.min(1.8, rate)));
          speaking = call;
          String uid = UUID.randomUUID().toString();
          Bundle params = new Bundle();
          int queued = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, uid);
          if (queued == TextToSpeech.ERROR) {
            speaking = null;
            call.reject("did not speak");
          }
        },
        call);
  }

  @PluginMethod
  public void stop(PluginCall call) {
    if (getActivity() == null) {
      call.resolve();
      return;
    }
    getActivity()
        .runOnUiThread(
            () -> {
              if (tts != null) tts.stop();
              if (speaking != null) {
                speaking.reject("stopped");
                speaking = null;
              }
              call.resolve();
            });
  }

  @PluginMethod
  public void openDownload(PluginCall call) {
    withEngine(
        () -> {
          String engine = tts.getDefaultEngine();
          if (launch(settingsIntent()) || launch(installIntent(engine)) || launch(installIntent(null))) {
            call.resolve();
            return;
          }
          call.reject("no voice download");
        },
        call);
  }

  private Intent installIntent(String engine) {
    Intent intent = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
    if (engine != null && !engine.isEmpty()) intent.setPackage(engine);
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    return intent;
  }

  private Intent settingsIntent() {
    Intent intent = new Intent("com.android.settings.TTS_SETTINGS");
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    return intent;
  }

  private boolean launch(Intent intent) {
    PackageManager packages = getContext().getPackageManager();
    if (intent.resolveActivity(packages) == null) return false;
    try {
      getContext().startActivity(intent);
      return true;
    } catch (Exception ignored) {
      return false;
    }
  }

  @PluginMethod
  public void fetchStory(PluginCall call) {
    String text = call.getString("text", "");
    String neural = call.getString("neural", "zh-CN-XiaoyiNeural");
    String rate = call.getString("rate", "+0%");
    String pitch = call.getString("pitch", "+0Hz");
    if (text == null || text.trim().isEmpty()) {
      call.reject("empty");
      return;
    }
    String url =
        "wss://api.msedgeservices.com/tts/cognitiveservices/websocket/v1?Ocp-Apim-Subscription-Key="
            + TOKEN
            + "&Sec-MS-GEC="
            + secToken()
            + "&Sec-MS-GEC-Version=1-143.0.3650.75&ConnectionId="
            + UUID.randomUUID().toString().replace("-", "");
    Request request =
        new Request.Builder()
            .url(url)
            .header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .build();
    ByteArrayOutputStream audio = new ByteArrayOutputStream();
    boolean[] settled = new boolean[] {false};
    http.newWebSocket(
        request,
        new WebSocketListener() {
          @Override
          public void onOpen(WebSocket webSocket, Response response) {
            String stamp = stamp();
            String config =
                "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{\"sentenceBoundaryEnabled\":false,\"wordBoundaryEnabled\":false},\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}";
            webSocket.send(
                "X-Timestamp:"
                    + stamp
                    + "\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n"
                    + config);
            String ssml =
                "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'><voice name='"
                    + xml(neural)
                    + "'><prosody pitch='"
                    + xml(pitch)
                    + "' rate='"
                    + xml(rate)
                    + "' volume='+0%'>"
                    + xml(text)
                    + "</prosody></voice></speak>";
            webSocket.send(
                "X-RequestId:"
                    + UUID.randomUUID().toString().replace("-", "")
                    + "\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:"
                    + stamp
                    + "Z\r\nPath:ssml\r\n\r\n"
                    + ssml);
          }

          @Override
          public void onMessage(WebSocket webSocket, String message) {
            if (message != null && message.contains("Path:turn.end")) webSocket.close(1000, "done");
          }

          @Override
          public void onMessage(WebSocket webSocket, ByteString bytes) {
            byte[] data = bytes.toByteArray();
            if (data.length < 2) return;
            int header = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
            int start = header + 2;
            if (data.length > start) audio.write(data, start, data.length - start);
          }

          @Override
          public void onClosed(WebSocket webSocket, int code, String reason) {
            finish(call, audio, settled, null);
          }

          @Override
          public void onFailure(WebSocket webSocket, Throwable t, Response response) {
            finish(call, audio, settled, t);
          }
        });
  }

  private void finish(PluginCall call, ByteArrayOutputStream audio, boolean[] settled, Throwable err) {
    if (settled[0]) return;
    settled[0] = true;
    byte[] bytes = audio.toByteArray();
    if (bytes.length > 1200) {
      JSObject result = new JSObject();
      result.put("b64", Base64.encodeToString(bytes, Base64.NO_WRAP));
      call.resolve(result);
      return;
    }
    call.reject(err == null ? "empty voice" : String.valueOf(err.getMessage()));
  }

  private void withEngine(Runnable task, PluginCall call) {
    if (getActivity() == null) {
      call.reject("no screen");
      return;
    }
    getActivity()
        .runOnUiThread(
            () -> {
              if (ready && tts != null) {
                task.run();
                return;
              }
              waiting.add(task);
              if (tts != null) return;
              tts =
                  new TextToSpeech(
                      getContext(),
                      status -> {
                        ready = status == TextToSpeech.SUCCESS;
                        tts.setOnUtteranceProgressListener(
                            new UtteranceProgressListener() {
                              @Override
                              public void onStart(String utteranceId) {}

                              @Override
                              public void onDone(String utteranceId) {
                                PluginCall pending = speaking;
                                speaking = null;
                                if (pending != null) pending.resolve();
                              }

                              @Override
                              public void onError(String utteranceId) {
                                PluginCall pending = speaking;
                                speaking = null;
                                if (pending != null) pending.reject("did not speak");
                              }
                            });
                        List<Runnable> copy = new ArrayList<>(waiting);
                        waiting.clear();
                        if (!ready) {
                          call.reject("no phone voice");
                          return;
                        }
                        for (Runnable job : copy) job.run();
                      });
            });
  }

  private static String joinFeatures(Set<String> features) {
    StringBuilder joined = new StringBuilder();
    for (String feature : features) {
      if (joined.length() > 0) joined.append(' ');
      joined.append(feature);
    }
    return joined.toString();
  }

  private static String xml(String value) {
    if (value == null) return "";
    return value
        .replace("&", "&" + "amp;")
        .replace("<", "&" + "lt;")
        .replace(">", "&" + "gt;")
        .replace("'", "&" + "apos;")
        .replace("\"", "&" + "quot;");
  }

  private static String stamp() {
    return new java.text.SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.US).format(new java.util.Date());
  }

  private static String secToken() {
    try {
      double ticks = System.currentTimeMillis() / 1000.0;
      ticks += 11644473600.0;
      ticks -= ticks % 300.0;
      ticks *= 10000000.0;
      String raw = String.format(Locale.US, "%.0f", ticks) + TOKEN;
      byte[] hash = MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
      StringBuilder out = new StringBuilder();
      for (byte b : hash) out.append(String.format(Locale.US, "%02X", b));
      return out.toString();
    } catch (Exception err) {
      return "";
    }
  }
}
